package mvf.mikevidev.walkandsee;

//This class will contain methods to process the places found in each city
public class FinderHelper
{
    
}
